/* =========================================================
   For Madhuri 💗 — interaction logic
   Plain vanilla JS. No backend.
   ========================================================= */

/* ---------------------------------------------------------
   1) CAT ASSETS  —  EASY TO CUSTOMIZE
   Swap these paths with your own animated .gif files.
   Just drop the .gif into /assets/gifs/ and change the value.
   e.g.  hello: "assets/gifs/hello-cat.gif"
   --------------------------------------------------------- */
const CAT_ASSETS = {
  hello:    "assets/gifs/hello-cat.png",     // Screen 1 - waving/greeting
  shy:      "assets/gifs/shy-cat.png",       // shy / blushing
  happy:    "assets/gifs/happy-cat.png",     // Screen 2 - excited
  thinking: "assets/gifs/thinking-cat.png",  // Screen 3 - calendar
  play:     "assets/gifs/thinking-play-cat.png", // Screen 4 - playful
  love:     "assets/gifs/love-cat.png",      // Screen 6 - holding heart
  couple:   "assets/gifs/couple.png",        // Screen 5 - two cats
};

/* ---------------------------------------------------------
   BACKGROUND MUSIC  —  EASY TO CUSTOMIZE
   "I Like Me Better" by Lauv.
   The real song is NOT bundled (copyright). Drop a licensed MP3
   at assets/audio/i-like-me-better.mp3 and it plays automatically.
   Until then, a soft chiptune placeholder is used.
   --------------------------------------------------------- */
const MUSIC_SRC = "assets/audio/i-like-me-better.mp3";
const MUSIC_START_SECONDS = 53;   // start at the catchy "I like me better..." hook
const MUSIC_VOLUME = 0.28;         // soft, so it never overpowers the message
const MUSIC_FADE_SECONDS = 2.5;    // smooth fade-in

/* Your signature on the love note — change this! */
const SIGNATURE = "— your secret admirer 🐾";

/* The love note message */
const LOVE_NOTE =
  "Madhuri, you have beautiful eyes and an even more beautiful heart. " +
  "But honestly, your smile is the most special thing about you. " +
  "Whenever you smile, somehow it brings a smile to my face too. 💗";

/* Shared app state */
const state = { date: null, activity: null };

/* ---------------------------------------------------------
   2) Boot: assign cat images + signature
   --------------------------------------------------------- */
document.querySelectorAll(".cat").forEach((img) => {
  const key = img.getAttribute("data-cat");
  if (CAT_ASSETS[key]) {
    img.src = CAT_ASSETS[key];
    img.onerror = () => makePlaceholder(img, key);
  }
});
document.getElementById("signature").textContent = SIGNATURE;

/* If a cat asset is missing, draw a clearly-labeled cute placeholder */
function makePlaceholder(img, key) {
  const svg = encodeURIComponent(`
    <svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'>
      <rect width='160' height='160' fill='#ffe3ef'/>
      <text x='80' y='70' font-size='46' text-anchor='middle'>🐱</text>
      <text x='80' y='110' font-family='monospace' font-size='13' fill='#5b2a48' text-anchor='middle'>${key}-cat</text>
      <text x='80' y='128' font-family='monospace' font-size='10' fill='#ff4d8d' text-anchor='middle'>(add .gif here)</text>
    </svg>`);
  img.src = `data:image/svg+xml,${svg}`;
}

/* ---------------------------------------------------------
   3) Loader
   --------------------------------------------------------- */
const loader = document.getElementById("loader");
const loaderFill = document.getElementById("loaderFill");
const loaderPct = document.getElementById("loaderPct");
let pct = 0;
const loadTimer = setInterval(() => {
  pct = Math.min(100, pct + Math.round(Math.random() * 16) + 6);
  loaderFill.style.width = pct + "%";
  loaderPct.textContent = pct + "%";
  if (pct >= 100) {
    clearInterval(loadTimer);
    setTimeout(() => {
      loader.classList.add("hide");
      showScreen(1);
    }, 350);
  }
}, 160);

/* ---------------------------------------------------------
   4) Screen transitions
   --------------------------------------------------------- */
let current = 0;
function showScreen(n) {
  const next = document.getElementById("screen-" + n);
  if (!next) return;
  const prev = document.querySelector(".screen.is-active");
  if (prev && prev !== next) {
    prev.classList.remove("enter");
    setTimeout(() => prev.classList.remove("is-active"), 250);
  }
  next.classList.add("is-active");
  // reset escaping NO button if we leave screen 1
  requestAnimationFrame(() => {
    requestAnimationFrame(() => next.classList.add("enter"));
  });
  current = n;
  window.scrollTo({ top: 0, behavior: "smooth" });
}

/* generic "next" buttons */
document.querySelectorAll("[data-next]").forEach((btn) => {
  btn.addEventListener("click", (e) => {
    click();
    heartBurst(e);
    const target = Number(btn.getAttribute("data-next"));
    if (target === 6) buildNote();
    showScreen(target);
    if (target === 5) fillSummary();
  });
});

/* ---------------------------------------------------------
   5) Screen 1 — YES / NO
   --------------------------------------------------------- */
const yesBtn = document.getElementById("yesBtn");
const noBtn = document.getElementById("noBtn");

yesBtn.addEventListener("click", (e) => {
  click(true);
  heartBurst(e, 14);
  showScreen(2);
});

/* NO button runs away */
function dodge() {
  const pad = 12;
  const bw = noBtn.offsetWidth || 90;
  const bh = noBtn.offsetHeight || 50;
  const maxX = window.innerWidth - bw - pad;
  const maxY = window.innerHeight - bh - pad;
  const x = Math.max(pad, Math.floor(Math.random() * maxX));
  const y = Math.max(pad, Math.floor(Math.random() * maxY));
  noBtn.classList.add("escaping");
  noBtn.style.left = x + "px";
  noBtn.style.top = y + "px";
  // playful shrink
  const scale = Math.max(0.6, (parseFloat(noBtn.dataset.scale || "1") - 0.06));
  noBtn.dataset.scale = scale;
  noBtn.style.transform = `scale(${scale})`;
  blip(220);
}
noBtn.addEventListener("mouseenter", dodge);
noBtn.addEventListener("click", (e) => { e.preventDefault(); dodge(); });
noBtn.addEventListener("touchstart", (e) => { e.preventDefault(); dodge(); }, { passive: false });

/* ---------------------------------------------------------
   6) Screen 3 — Date picker
   --------------------------------------------------------- */
const dateInput = document.getElementById("dateInput");
const dateContinue = document.getElementById("dateContinue");
const dateHint = document.getElementById("dateHint");

// default min = today
const today = new Date();
dateInput.min = today.toISOString().split("T")[0];

dateInput.addEventListener("change", () => {
  if (dateInput.value) {
    state.date = dateInput.value;
    dateContinue.disabled = false;
    dateHint.textContent = "yay, that day sounds perfect! 💗";
    click();
  }
});
dateContinue.addEventListener("click", (e) => {
  if (!state.date) return;
  click(); heartBurst(e);
  showScreen(4);
});

/* ---------------------------------------------------------
   7) Screen 4 — Activities
   --------------------------------------------------------- */
const grid = document.getElementById("activityGrid");
const lockBtn = document.getElementById("lockBtn");
const reaction = document.getElementById("activityReaction");
const reactions = {
  "Dinner Date 🍕": "yum, a dinner date?! 😻",
  "Movie Night 🎬": "cozy movie night, i love it! 🍿",
  "Coffee & Walk ☕": "coffee & a walk, so cute 💕",
  "Picnic 🧺": "a picnic sounds dreamy! 🌸",
  "Mini Golf ⛳": "mini golf, you&apos;re on! 😼",
  "Surprise Me 🎁": "ooh, leave it to me... 🎁✨",
};

grid.querySelectorAll(".activity").forEach((btn) => {
  btn.addEventListener("click", (e) => {
    grid.querySelectorAll(".activity").forEach((b) => b.classList.remove("selected"));
    btn.classList.add("selected");
    state.activity = btn.getAttribute("data-activity");
    lockBtn.disabled = false;
    reaction.innerHTML = reactions[state.activity] || "great choice! ✨";
    click(); heartBurst(e, 6);
  });
});
lockBtn.addEventListener("click", (e) => {
  if (!state.activity) return;
  click(true); heartBurst(e, 10);
  fillSummary();
  showScreen(5);
  confettiRain();
});

/* ---------------------------------------------------------
   8) Screen 5 — summary
   --------------------------------------------------------- */
function fillSummary() {
  const d = state.date ? formatDate(state.date) : "—";
  document.getElementById("outDate").textContent = d;
  document.getElementById("outActivity").textContent = state.activity || "—";
}
function formatDate(iso) {
  const [y, m, day] = iso.split("-").map(Number);
  const dt = new Date(y, m - 1, day);
  return dt.toLocaleDateString(undefined, {
    weekday: "long", year: "numeric", month: "long", day: "numeric",
  });
}

/* ---------------------------------------------------------
   9) Screen 6 — typewriter love note
   --------------------------------------------------------- */
const noteEl = document.getElementById("noteText");
let noteTyped = false;
function buildNote() {
  if (noteTyped) return;
  noteTyped = true;
  let i = 0;
  noteEl.innerHTML = "<span class='caret'>▍</span>";
  const type = () => {
    if (i <= LOVE_NOTE.length) {
      noteEl.innerHTML = LOVE_NOTE.slice(0, i) + "<span class='caret'>▍</span>";
      i++;
      if (i % 2 === 0) blip(660, 0.02, 0.02);
      setTimeout(type, 34);
    } else {
      noteEl.innerHTML = LOVE_NOTE;
    }
  };
  setTimeout(type, 400);
}

document.getElementById("restartBtn").addEventListener("click", (e) => {
  click(); heartBurst(e);
  state.date = null; state.activity = null;
  noteTyped = false;
  dateInput.value = ""; dateContinue.disabled = true;
  dateHint.textContent = "tap the box to open the calendar";
  lockBtn.disabled = true;
  reaction.innerHTML = "pick your favorite ✨";
  grid.querySelectorAll(".activity").forEach((b) => b.classList.remove("selected"));
  noBtn.classList.remove("escaping");
  noBtn.removeAttribute("style");
  noBtn.dataset.scale = "1";
  showScreen(1);
});

/* ---------------------------------------------------------
   10) Floating hearts / stars in the sky
   --------------------------------------------------------- */
const floaters = document.getElementById("floaters");
const GLYPHS = ["💗", "✨", "⭐", "🌸", "💕", "🩷"];
function spawnFloater() {
  const s = document.createElement("span");
  s.className = "floater";
  s.textContent = GLYPHS[Math.floor(Math.random() * GLYPHS.length)];
  s.style.left = Math.random() * 100 + "vw";
  s.style.fontSize = 12 + Math.random() * 18 + "px";
  const dur = 7 + Math.random() * 7;
  s.style.animationDuration = dur + "s";
  floaters.appendChild(s);
  setTimeout(() => s.remove(), dur * 1000);
}
setInterval(spawnFloater, 900);

/* ---------------------------------------------------------
   11) Heart burst on click
   --------------------------------------------------------- */
function heartBurst(e, count = 8) {
  const x = e && e.clientX ? e.clientX : window.innerWidth / 2;
  const y = e && e.clientY ? e.clientY : window.innerHeight / 2;
  for (let i = 0; i < count; i++) {
    const s = document.createElement("span");
    s.className = "spark";
    s.textContent = Math.random() > 0.5 ? "💗" : "✨";
    s.style.left = x + "px";
    s.style.top = y + "px";
    const ang = Math.random() * Math.PI * 2;
    const dist = 40 + Math.random() * 70;
    s.style.setProperty("--dx", Math.cos(ang) * dist + "px");
    s.style.setProperty("--dy", (Math.sin(ang) * dist - 30) + "px");
    document.body.appendChild(s);
    setTimeout(() => s.remove(), 720);
  }
}

/* ---------------------------------------------------------
   12) Confetti / hearts rain on final screen
   --------------------------------------------------------- */
function confettiRain() {
  const N = 60;
  for (let i = 0; i < N; i++) {
    setTimeout(() => {
      const s = document.createElement("span");
      s.className = "floater";
      s.textContent = GLYPHS[Math.floor(Math.random() * GLYPHS.length)];
      s.style.left = Math.random() * 100 + "vw";
      s.style.fontSize = 14 + Math.random() * 20 + "px";
      const dur = 5 + Math.random() * 4;
      s.style.animationDuration = dur + "s";
      floaters.appendChild(s);
      setTimeout(() => s.remove(), dur * 1000);
    }, i * 40);
  }
}

/* ---------------------------------------------------------
   13) Sound effects + background music (WebAudio, no files)
   --------------------------------------------------------- */
let audioCtx = null;
let musicOn = false;
let musicTimer = null;

function ensureAudio() {
  if (!audioCtx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (AC) audioCtx = new AC();
  }
  if (audioCtx && audioCtx.state === "suspended") audioCtx.resume();
  return audioCtx;
}

/* short blip */
function blip(freq = 520, dur = 0.06, vol = 0.05) {
  const ctx = ensureAudio();
  if (!ctx) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = "square";
  o.frequency.value = freq;
  g.gain.value = vol;
  o.connect(g); g.connect(ctx.destination);
  const t = ctx.currentTime;
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.start(t); o.stop(t + dur);
}

/* click sound (with a happy up-note variant) */
function click(happy = false) {
  blip(happy ? 720 : 460, 0.07, 0.06);
  if (happy) setTimeout(() => blip(960, 0.08, 0.05), 70);
}

/* ---- Real song track (with graceful fallback to chiptune) ---- */
const bgm = document.getElementById("bgm");
let songReady = false;   // true once the real MP3 is confirmed playable
let fadeTimer = null;

/* Detect whether the real audio file is available & playable */
if (bgm) {
  bgm.volume = 0;
  // canplay => the file exists and decoded successfully
  bgm.addEventListener("canplay", () => { songReady = true; }, { once: true });
  // error / missing source => stay on chiptune fallback
  bgm.addEventListener("error", () => { songReady = false; });
  const src = bgm.querySelector("source");
  if (src && src.addEventListener) {
    src.addEventListener("error", () => { songReady = false; });
  }
}

/* Smoothly ramp the <audio> volume to a target over `secs` seconds */
function fadeAudioTo(target, secs) {
  if (!bgm) return;
  if (fadeTimer) clearInterval(fadeTimer);
  const steps = Math.max(1, Math.round(secs * 30)); // ~30 fps
  const start = bgm.volume;
  let i = 0;
  fadeTimer = setInterval(() => {
    i++;
    const k = i / steps;
    bgm.volume = Math.min(1, Math.max(0, start + (target - start) * k));
    if (i >= steps) {
      clearInterval(fadeTimer);
      fadeTimer = null;
      bgm.volume = Math.min(1, Math.max(0, target));
      if (target === 0) bgm.pause();
    }
  }, Math.round((secs * 1000) / steps));
}

function startSong() {
  if (!bgm || !songReady) return false;
  try {
    // Start from the catchy hook, not the very beginning
    if (bgm.currentTime < MUSIC_START_SECONDS - 1 || bgm.currentTime === 0) {
      bgm.currentTime = MUSIC_START_SECONDS;
    }
    bgm.volume = 0;
    const p = bgm.play();
    if (p && p.catch) p.catch(() => {});
    fadeAudioTo(MUSIC_VOLUME, MUSIC_FADE_SECONDS); // smooth fade-in
    return true;
  } catch (e) {
    return false;
  }
}

/* ---- Original "flirty love song" (used when no licensed MP3 is present)
   A warm I–V–vi–IV progression (C · G · Am · F) with a sweet lead melody,
   a soft chord pad, and a mellow bassline. Composed from scratch, so it's
   free to ship. Loops gently and never overpowers the message. ---- */
const NOTE = {
  C3:130.81, D3:146.83, E3:164.81, F3:174.61, G3:196.00, A3:220.00, B3:246.94,
  C4:261.63, D4:293.66, E4:329.63, F4:349.23, G4:392.00, A4:440.00, B4:493.88,
  C5:523.25, D5:587.33, E5:659.25, F5:698.46, G5:783.99, A5:880.00,
};
const BPM = 92;
const BEAT = 60 / BPM;                 // seconds per beat
const STEP = BEAT / 2;                 // 8th-note step
const CHORDS = [                       // one bar each: root triad + bass
  { bass: NOTE.C3, pad: [NOTE.C4, NOTE.E4, NOTE.G4] }, // C   (I)
  { bass: NOTE.G3, pad: [NOTE.B3, NOTE.D4, NOTE.G4] }, // G   (V)
  { bass: NOTE.A3, pad: [NOTE.A3, NOTE.C4, NOTE.E4] }, // Am  (vi)
  { bass: NOTE.F3, pad: [NOTE.F3, NOTE.A3, NOTE.C4] }, // F   (IV)
];
// Lead melody: 8 eighth-notes per bar (null = rest), 4 bars = one loop
const LEAD = [
  [NOTE.E5, NOTE.G5, NOTE.E5, null, NOTE.C5, NOTE.E5, NOTE.D5, null],
  [NOTE.D5, NOTE.G5, NOTE.D5, null, NOTE.B4, NOTE.D5, NOTE.G4, null],
  [NOTE.C5, NOTE.E5, NOTE.A5, null, NOTE.G5, NOTE.E5, NOTE.C5, null],
  [NOTE.A4, NOTE.C5, NOTE.F5, null, NOTE.E5, NOTE.C5, NOTE.A4, null],
];

let musicGain = null;          // soft master bus for the tune
let seqBar = 0, seqStep = 0;   // playhead

function musicBus() {
  const ctx = ensureAudio();
  if (!ctx) return null;
  if (!musicGain) {
    musicGain = ctx.createGain();
    musicGain.gain.value = 0.0001;                     // start silent for fade-in
    musicGain.connect(ctx.destination);
  }
  return musicGain;
}

/* Play one tone through the music bus with a gentle ADSR */
function tone(freq, dur, { type = "triangle", vol = 0.06, attack = 0.02 } = {}) {
  const ctx = ensureAudio();
  const bus = musicBus();
  if (!ctx || !bus || !freq) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.value = freq;
  o.connect(g); g.connect(bus);
  const t = ctx.currentTime;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(vol, t + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.start(t); o.stop(t + dur + 0.02);
}

function playMusicStep() {
  const ctx = ensureAudio();
  if (!ctx || !musicOn || songReady) return;
  const chord = CHORDS[seqBar % CHORDS.length];
  // Downbeat of each bar: pluck the bass + a soft chord pad
  if (seqStep === 0) {
    tone(chord.bass, BEAT * 1.9, { type: "sine", vol: 0.09, attack: 0.03 });
    chord.pad.forEach((f) => tone(f, BEAT * 1.8, { type: "triangle", vol: 0.028, attack: 0.06 }));
  }
  // Mid-bar: light bass bounce for a flirty lilt
  if (seqStep === 4) {
    tone(chord.bass * 1.5, BEAT * 0.9, { type: "sine", vol: 0.05, attack: 0.03 });
  }
  // Lead melody note for this step
  const note = LEAD[seqBar % LEAD.length][seqStep];
  if (note) tone(note, STEP * 1.6, { type: "triangle", vol: 0.055, attack: 0.015 });

  seqStep = (seqStep + 1) % 8;
  if (seqStep === 0) seqBar = (seqBar + 1) % 4;
}

/* Smoothly fade the tune's master bus in/out */
function fadeTuneTo(target, secs) {
  const ctx = ensureAudio();
  const bus = musicBus();
  if (!ctx || !bus) return;
  const t = ctx.currentTime;
  bus.gain.cancelScheduledValues(t);
  bus.gain.setValueAtTime(Math.max(0.0001, bus.gain.value), t);
  bus.gain.exponentialRampToValueAtTime(Math.max(0.0001, target), t + secs);
}

const muteBtn = document.getElementById("muteBtn");
const muteIcon = document.getElementById("muteIcon");
function setMusic(on) {
  musicOn = on;
  muteIcon.textContent = on ? "🎵" : "🔇";
  muteBtn.title = on ? "Mute music" : "Play music";
  if (on) {
    ensureAudio();
    // Prefer the real song; if it isn't ready, use the chiptune loop.
    const started = startSong();
    if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
    if (!started) {
      musicTimer = setInterval(playMusicStep, 360);
    }
  } else {
    if (songReady && bgm && !bgm.paused) {
      fadeAudioTo(0, 0.6); // gentle fade-out then pause
    }
    if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
  }
}
muteBtn.addEventListener("click", () => { click(); setMusic(!musicOn); });

/* Try to start music on first interaction (browsers block autoplay) */
function primeAudioOnce() {
  ensureAudio();
  if (!musicOn) setMusic(true);
  window.removeEventListener("pointerdown", primeAudioOnce);
  window.removeEventListener("keydown", primeAudioOnce);
}
window.addEventListener("pointerdown", primeAudioOnce, { once: true });
window.addEventListener("keydown", primeAudioOnce, { once: true });

/* global click blips for any button we didn't wire explicitly */
document.addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (b && !b.dataset.silent) { /* most already play; this is a soft fallback */ }
});
