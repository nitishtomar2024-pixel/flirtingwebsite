HOW TO ADD THE REAL SONG ("I Like Me Better" - Lauv)
=====================================================

For copyright reasons the actual song is NOT bundled with this website.
Right now the site plays a soft chiptune placeholder instead.

To use the real track:

1) Get a properly licensed MP3 of "I Like Me Better" by Lauv.
2) Rename it to exactly:   i-like-me-better.mp3
3) Drop it into this folder:   assets/audio/i-like-me-better.mp3

That's it — the website will automatically detect the file, start it
from the catchy chorus hook, fade it in softly, and loop it. The
chiptune placeholder is only used when this file is missing.

You can fine-tune the playback in script.js (top of the file):

  MUSIC_SRC            -> path to the audio file
  MUSIC_START_SECONDS  -> where playback begins (default 53s = the
                          "I like me better when I'm with you" hook)
  MUSIC_VOLUME         -> soft target volume (0.0 - 1.0)
  MUSIC_FADE_SECONDS   -> length of the smooth fade-in
